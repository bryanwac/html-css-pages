const lightbox = document.createElement('div')
lightbox.id = 'lightbox'
document.body.appendChild(lightbox)
const gallerybtn = document.createElement('button')
gallerybtn.id = 'gallery-button'
document.body.appendChild(lightbox)



const images = document.querySelectorAll('.aimg')
images.forEach(image =>{
    image.addEventListener('click',() =>{
        const img = document.createElement("img")
        img.src = image.firstElementChild.src

        while(lightbox.firstElementChild){//n deixar a foto duplicada no lightbox
            lightbox.removeChild(lightbox.firstElementChild)
        }
        lightbox.classList.add("active")
        lightbox.appendChild(img)
    })
})

lightbox.addEventListener('click', e =>{
    if(e.target !== e.currentTarget) return
    lightbox.classList.remove('active')//ocultando o active do lbox
})